package com.example.darshanh.todoappdemo;

/**
 * Created by Bharat Ghimire on 27/11/15.
 */
public interface Direction {

        public static final int RIGHT=1000;
        public static final int LEFT=1001;
        public static final int UP=1100;
        public static final int DOWN=1101;
}