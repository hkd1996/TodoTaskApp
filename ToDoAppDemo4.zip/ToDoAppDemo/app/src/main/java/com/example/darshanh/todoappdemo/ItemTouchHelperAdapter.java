package com.example.darshanh.todoappdemo;

/**
 * Created by Bharat Ghimire on 27/11/15.
 */
public interface ItemTouchHelperAdapter {

   public void swipeToDelete(int position);

}
