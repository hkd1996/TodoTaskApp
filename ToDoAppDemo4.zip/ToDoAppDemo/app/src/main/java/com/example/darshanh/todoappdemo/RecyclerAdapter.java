package com.example.darshanh.todoappdemo;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import db.TodoTaskHelper;

import static db.TodoTaskHelper.TABLE_NAME;
import static db.TodoTaskHelper.TASK_DESCRIPTION;
import static db.TodoTaskHelper.TASK_ID;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.TaskViewHolder> implements ItemTouchHelperAdapter {

    Cursor cursor;
    Context context;

    public RecyclerAdapter(Cursor cursor,Context context) {
        this.cursor = cursor;
        this.context=context;
    }


    @NonNull
    @Override
    public TaskViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view= LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.recycler_view_with_delete,viewGroup,false);
        TaskViewHolder taskViewHolder=new TaskViewHolder(view);
        return taskViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull TaskViewHolder taskViewHolder, int i) {
        cursor.moveToPosition(i);
        String text=cursor.getString(1);
        taskViewHolder.task_list.setText(text);

    }

    @Override
    public int getItemCount() {
        return cursor.getCount();
    }

    @Override
    public void swipeToDelete(int position) {
        cursor.moveToPosition(position);
        String task=cursor.getString(0);
        TodoTaskHelper todoTaskHelper=new TodoTaskHelper(context);
        SQLiteDatabase sqLiteDatabase = todoTaskHelper.getWritableDatabase();
        sqLiteDatabase.execSQL("DELETE FROM " + TABLE_NAME+ " WHERE "+TASK_ID+"='"+task+"'");
        cursor=sqLiteDatabase.rawQuery("select * from "+TodoTaskHelper.TABLE_NAME,null);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position,cursor.getCount());

        sqLiteDatabase.close();
    }

    public class TaskViewHolder extends RecyclerView.ViewHolder {
        TextView task_list;
        public RelativeLayout viewBackground, viewForeground;

        public TaskViewHolder(@NonNull View itemView) {
            super(itemView);
            task_list=itemView.findViewById(R.id.task_list);
            viewForeground=itemView.findViewById(R.id.view_foreground);
        }
    }
}
